package com.juli.imccalculator.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class IMCViewModel : ViewModel() {

    private val _peso = MutableStateFlow("")
    val peso: StateFlow<String> = _peso

    private val _altura = MutableStateFlow("")
    val altura: StateFlow<String> = _altura

    private val _imc = MutableStateFlow(0.0)
    val imc: StateFlow<Double> = _imc

    private val _mensajeIMC = MutableStateFlow("")
    val mensajeIMC: StateFlow<String> = _mensajeIMC

    fun onPesoChange(value: String) {
        _peso.value = value
    }

    fun onAlturaChange(value: String) {
        _altura.value = value
    }

    fun calcularIMC() {
        val pesoValue = _peso.value.toDoubleOrNull() ?: 0.0
        val alturaValue = _altura.value.toDoubleOrNull() ?: 0.0

        if (pesoValue > 0 && alturaValue > 0) {
            val imcResult = pesoValue / (alturaValue * alturaValue)
            _imc.value = imcResult
            _mensajeIMC.value = obtenerCategoriaIMC(imcResult)
        } else {
            _imc.value = 0.0
            _mensajeIMC.value = "Datos inválidos"
        }
    }

    private fun obtenerCategoriaIMC(imc: Double): String {
        return when {
            imc < 18.5 -> "Bajo peso"
            imc < 24.9 -> "Peso saludable"
            imc < 29.9 -> "Sobrepeso"
            else -> "Obesidad"
        }
    }
}
