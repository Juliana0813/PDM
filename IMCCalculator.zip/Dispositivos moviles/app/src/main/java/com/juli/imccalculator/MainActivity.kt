package com.juli.imccalculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.juli.imccalculator.ui.theme.IMCCalculatorTheme
import com.juli.imccalculator.viewmodel.IMCViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: IMCViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IMCCalculatorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    IMCPantalla(viewModel)
                }
            }
        }
    }
}

@Composable
fun IMCPantalla(viewModel: IMCViewModel) {
    val peso by viewModel.peso.collectAsState()
    val altura by viewModel.altura.collectAsState()
    val imc by viewModel.imc.collectAsState()
    val mensajeIMC by viewModel.mensajeIMC.collectAsState()

    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Calculadora de IMC",
            style = MaterialTheme.typography.headlineMedium
        )

        OutlinedTextField(
            value = peso,
            onValueChange = { viewModel.onPesoChange(it) },
            label = { Text("Peso (kg)") },
            singleLine = true
        )

        OutlinedTextField(
            value = altura,
            onValueChange = { viewModel.onAlturaChange(it) },
            label = { Text("Altura (m)") },
            singleLine = true
        )

        Button(
            onClick = { viewModel.calcularIMC() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Calcular")
        }

        AnimatedVisibility(visible = imc > 0.0) {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Tu IMC es: ${String.format("%.2f", imc)}",
                    style = MaterialTheme.typography.headlineSmall
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.Transparent
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(obtenerGradienteCategoria(mensajeIMC))
                            .padding(16.dp)
                            .fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = obtenerIconoCategoria(mensajeIMC),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = mensajeIMC,
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun obtenerIconoCategoria(mensaje: String): ImageVector {
    return when (mensaje) {
        "Bajo peso" -> Icons.Default.Info
        "Peso saludable" -> Icons.Default.CheckCircle
        "Sobrepeso" -> Icons.Default.Warning
        "Obesidad" -> Icons.Default.Close
        else -> Icons.Default.Info
    }
}

fun obtenerGradienteCategoria(mensaje: String): Brush {
    return when (mensaje) {
        "Bajo peso" -> Brush.horizontalGradient(
            colors = listOf(Color(0xFF64B5F6), Color(0xFF1976D2))
        )
        "Peso saludable" -> Brush.horizontalGradient(
            colors = listOf(Color(0xFF81C784), Color(0xFF388E3C))
        )
        "Sobrepeso" -> Brush.horizontalGradient(
            colors = listOf(Color(0xFFFFB74D), Color(0xFFF57C00))
        )
        "Obesidad" -> Brush.horizontalGradient(
            colors = listOf(Color(0xFFE57373), Color(0xFFD32F2F))
        )
        else -> Brush.horizontalGradient(
            colors = listOf(Color.LightGray, Color.DarkGray)
        )
    }
}
