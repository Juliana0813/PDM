from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware

from app import models, schemas, crud

from app.database import SessionLocal, engine


models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="API de Fútbol ⚽",
    description="Gestor de jugadores",
    version="1.0.0"
)


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/jugadores/", response_model=list[schemas.Jugador])
def leer_jugadores(db: Session = Depends(get_db)):
    return crud.get_jugadores(db)


@app.post("/jugadores/", response_model=schemas.Jugador)
def crear_jugador(jugador: schemas.JugadorCreate, db: Session = Depends(get_db)):
    return crud.create_jugador(db, jugador)
