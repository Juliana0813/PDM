from sqlalchemy.orm import Session

from app import models
from app import schemas

def get_jugadores(db: Session):
    return db.query(models.Jugador).all()

def create_jugador(db: Session, jugador: schemas.JugadorCreate):
    db_jugador = models.Jugador(
        nombre=jugador.nombre,
        posicion=jugador.posicion,
        equipo=jugador.equipo
    )
    db.add(db_jugador)
    db.commit()
    db.refresh(db_jugador)
    return db_jugador
